// Problem 4
// Source: https://w3resource.com/swift-programming-exercises/array/index.php#editorr
// Question 1: Write a Swift program to check if 5 appears as either the first or last element in a given array of integers. The array length should be 1 or more.

var arrayOfInts: [Int] = [5, 2, 0]

if arrayOfInts.first == 5 {
    print ("The  first element of this array is 5 ")
}else if arrayOfInts.last == 5{
    print("The last element of this array is 5")
}

//Problem 5, Question: Write a Swift program to rotate the elements of an array of integers to left direction. Therefore {1, 2, 3} yields {2, 3, 1}.

var arrayOfInts2: [Int] = [1, 2, 3, 4]

var arrayOfInts3 = arrayOfInts2
arrayOfInts3.removeFirst()
arrayOfInts3.append(arrayOfInts2.first!) //need to unwrap optional int in case no first value of 'arrayOfInts2'
print (arrayOfInts3)

