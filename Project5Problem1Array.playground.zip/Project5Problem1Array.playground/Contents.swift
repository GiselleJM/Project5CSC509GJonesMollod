//Problems from 'Coding Bat'

//Given an array of ints, return true if 6 appears as either the first or last element in the array. The array will be length 1 or more.

var firstLastSix: [Int] = [6, 2, 3]


    if firstLastSix[0] == 6 || firstLastSix[firstLastSix.count-1] == 6 {
        print (true)
    }else{
        print(false)
}



                            //Max End 3
// Given an array of ints length 3, figure out which is larger, the first or last element in the array, and set all the other elements to be that value. Return the changed array.


var maxEndThree:[Int] = [11, 5, 9]
var greatestNumber:Int = maxEndThree[0]


for number in maxEndThree{
    if number > greatestNumber{
        greatestNumber = number
    }
    maxEndThree[0..<maxEndThree.count] = [greatestNumber, greatestNumber, greatestNumber]
}

print(greatestNumber)
print(maxEndThree)


//Return the sum of the numbers in the array, returning 0 for an empty array. Except the number 13 is very unlucky, so it does not count and numbers that come immediately after a 13 also do not count.

var sum13: [Int] = [5, 5, 13]
var thirteenHolder = 0
var sum: Int = 0
var newSum = 0

for number in sum13[0..<sum13.count]{
    sum += number
    if number == 13{
        thirteenHolder += 13
}
  newSum = sum - thirteenHolder
}
print(newSum)
print(thirteenHolder)
